import { useState } from "react";
import "../styles/Login.css";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);

  const isReady = email.length > 3 && password.length > 3;

  function handleSubmit() {
    if (!isReady) return;
    onLogin({ name: "Carlos Mendoza", location: "Longchamps", email });
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        <div className="login-logo">
          <div className="logo-icon">🔧</div>
          <div className="logo-text">
            Plomer<span>IA</span>
          </div>
        </div>

        <h1 className="login-title">Bienvenido de nuevo</h1>
        <p className="login-sub">Ingresá con tu cuenta para continuar</p>

        <div className="field-wrap">
          <label className="field-label">Correo electrónico</label>
          <input
            className="field-input"
            type="email"
            placeholder="tu@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </div>

        <div className="field-wrap">
          <label className="field-label">Contraseña</label>
          <div className="pass-wrap">
            <input
              className="field-input"
              type={showPass ? "text" : "password"}
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button
              className="pass-toggle"
              onClick={() => setShowPass(!showPass)}
              aria-label="Mostrar contraseña"
            >
              {showPass ? "🙈" : "👁"}
            </button>
          </div>
        </div>

        <a className="forgot-link">¿Olvidaste tu contraseña?</a>

        <button
          className={`btn-login ${isReady ? "active" : ""}`}
          onClick={handleSubmit}
        >
          Ingresar →
        </button>

        <p className="divider">¿Primera vez?</p>

        <div className="register-grid">
          <div className="reg-card">
            <span className="reg-icon">🏠</span>
            <span className="reg-label">Soy cliente</span>
            <span className="reg-sub">Necesito un plomero</span>
          </div>
          <div className="reg-card green">
            <span className="reg-icon">🔧</span>
            <span className="reg-label green">Soy plomero</span>
            <span className="reg-sub">Quiero ofrecer servicios</span>
          </div>
        </div>
      </div>
    </div>
  );
}
