import { useState, useEffect } from "react";
import "../styles/JobCard.css";

function formatTime(seconds) {
  if (seconds >= 3600) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${h}h ${m}m`;
  }
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function JobCard({ job, onAccept, onReject }) {
  const [timeLeft, setTimeLeft] = useState(job.timerSeconds);
  const [accepted, setAccepted] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (timeLeft <= 0) return;
    const interval = setInterval(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearInterval(interval);
  }, [timeLeft]);

  useEffect(() => {
    if (accepted) {
      const t = setTimeout(() => onAccept(job.id), 2500);
      return () => clearTimeout(t);
    }
  }, [accepted]);

  const pct = Math.round((timeLeft / job.timerTotal) * 100);
  const isUrgent = job.urgent;

  if (accepted) {
    return (
      <div className={`job-card accepted`}>
        <div className="accepted-inner">
          <span className="accepted-icon">✅</span>
          <p className="accepted-title">¡Trabajo aceptado!</p>
          <p className="accepted-sub">
            La dirección del cliente ya está disponible en <strong>En curso</strong>.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={`job-card ${isUrgent ? "urgent" : ""}`}>
      {/* Tags */}
      <div className="tag-row">
        <span className={`tag tag-${job.category.toLowerCase()}`}>{job.category}</span>
        {isUrgent && <span className="tag tag-urgente">⚠️ URGENTE</span>}
      </div>

      {/* Meta */}
      <div className="job-meta">
        <span>📍 {job.location} · {job.time}</span>
        {job.turno && (
          <span className="turno">📅 Turno sugerido: {job.turno}</span>
        )}
      </div>

      {/* Timer */}
      <div className={`timer-box ${isUrgent ? "urgent-timer" : "normal-timer"}`}>
        <div className={`timer-label ${isUrgent ? "" : "blue"}`}>
          {isUrgent ? "⚠️" : "🕐"} TIEMPO PARA RESPONDER
        </div>
        <div className="timer-row">
          <span className={`timer-value ${isUrgent ? "" : "blue"}`}>
            {formatTime(timeLeft)}
          </span>
          <div className="timer-bar">
            <div
              className={`timer-fill ${isUrgent ? "orange" : "blue"}`}
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      </div>

      {/* Descripción */}
      <div className="desc-box">
        <div className="desc-label">LO QUE DESCRIBE EL CLIENTE</div>
        <p className="desc-text">
          "{expanded ? job.description : job.description.slice(0, 100) + "..."}"
        </p>
        <button className="ver-mas" onClick={() => setExpanded(!expanded)}>
          {expanded ? "Ver menos ↑" : "Ver más ↓"}
        </button>
      </div>

      {/* Nota dirección */}
      <p className="address-note">
        🔒 La dirección exacta se revela solo si aceptás el trabajo
      </p>

      {/* Botones */}
      <div className="btn-row">
        <button className="btn-reject" onClick={() => onReject(job.id)}>
          ✕ Rechazar
        </button>
        <button className="btn-accept" onClick={() => setAccepted(true)}>
          ✓ Aceptar trabajo
        </button>
      </div>
    </div>
  );
}
