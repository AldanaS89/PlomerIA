import "../styles/NavTabs.css";

const TABS = [
  { id: "solicitudes", label: "Solicitudes", icon: "📥" },
  { id: "en-curso",    label: "En curso",    icon: "✏️" },
  { id: "agenda",      label: "Mi agenda",   icon: "📅" },
  { id: "historial",   label: "Historial",   icon: "🕐" },
];

export default function NavTabs({ activeTab, onTabChange, jobCount }) {
  return (
    <nav className="nav-tabs">
      {TABS.map((tab) => (
        <button
          key={tab.id}
          className={`nav-tab ${activeTab === tab.id ? "active" : ""}`}
          onClick={() => onTabChange(tab.id)}
        >
          <span className="tab-icon">{tab.icon}</span>
          {tab.label}
          {tab.id === "solicitudes" && jobCount > 0 && (
            <span className="tab-badge">{jobCount}</span>
          )}
        </button>
      ))}
    </nav>
  );
}
