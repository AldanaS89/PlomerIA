import { useState } from "react";
import Header from "./Header";
import NavTabs from "./NavTabs";
import JobCard from "./JobCard";
import "../styles/Dashboard.css";

const INITIAL_JOBS = [
  {
    id: "job-1",
    category: "Urgencias",
    urgent: true,
    location: "Longchamps",
    time: "Hoy, 14:32",
    timerSeconds: 27 * 60 + 6,
    timerTotal: 30 * 60,
    description:
      "Se me rompió una cañería debajo de la pileta y el agua no para de salir. Ya cerré la llave de paso pero necesito que lo arreglen hoy.",
    turno: null,
  },
  {
    id: "job-2",
    category: "Destapes",
    urgent: false,
    location: "Monte Grande",
    time: "Hoy, 11:15",
    timerSeconds: 2 * 3600 + 57 * 60,
    timerTotal: 4 * 3600,
    description:
      "Tengo un destape en el baño principal, el agua tarda mucho en bajar. No es urgente pero me gustaría que lo vean esta semana.",
    turno: "14/05/2026 a las 10:00 hs",
  },
];

export default function Dashboard({ user, onLogout }) {
  const [activeTab, setActiveTab] = useState("solicitudes");
  const [jobs, setJobs] = useState(INITIAL_JOBS);
  const [active, setActive] = useState(true);

  function handleAccept(id) {
    setJobs((prev) => prev.filter((j) => j.id !== id));
  }

  function handleReject(id) {
    setJobs((prev) => prev.filter((j) => j.id !== id));
  }

  return (
    <div className="dashboard">
      <Header user={user} active={active} onToggleActive={() => setActive(!active)} />
      <NavTabs activeTab={activeTab} onTabChange={setActiveTab} jobCount={jobs.length} />

      <div className="dash-body">
        {activeTab === "solicitudes" && (
          <>
            <h2 className="section-title">Solicitudes entrantes</h2>
            <p className="section-sub">
              El primero en aceptar queda asignado · La dirección se revela al aceptar
            </p>
            {jobs.length === 0 ? (
              <div className="empty-state">
                <span className="empty-icon">📭</span>
                <p>No hay solicitudes por ahora</p>
              </div>
            ) : (
              jobs.map((job) => (
                <JobCard
                  key={job.id}
                  job={job}
                  onAccept={handleAccept}
                  onReject={handleReject}
                />
              ))
            )}
          </>
        )}

        {activeTab === "en-curso" && (
          <div className="empty-state">
            <span className="empty-icon">✏️</span>
            <p>No tenés trabajos en curso</p>
          </div>
        )}

        {activeTab === "agenda" && (
          <div className="empty-state">
            <span className="empty-icon">📅</span>
            <p>Tu agenda está vacía</p>
          </div>
        )}

        {activeTab === "historial" && (
          <div className="empty-state">
            <span className="empty-icon">🕐</span>
            <p>No hay historial todavía</p>
          </div>
        )}
      </div>
    </div>
  );
}
