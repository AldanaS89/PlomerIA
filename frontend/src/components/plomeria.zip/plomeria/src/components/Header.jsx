import "../styles/Header.css";

export default function Header({ user, active, onToggleActive }) {
  return (
    <div className="dash-header">
      <div className="dash-avatar">🔧</div>
      <div className="dash-user">
        <div className="dash-name">{user?.name ?? "Plomero"}</div>
        <div className="dash-loc">📍 {user?.location ?? ""}</div>
      </div>
      <div className="dash-active">
        <span className="active-label">Activo</span>
        <button
          className={`toggle ${active ? "on" : "off"}`}
          onClick={onToggleActive}
          aria-label="Toggle disponibilidad"
        />
      </div>
    </div>
  );
}
