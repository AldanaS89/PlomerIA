# PlomerIA — Frontend

## Estructura

```
src/
├── App.jsx                  # Raíz: maneja la navegación entre pantallas
├── styles/
│   ├── global.css           # Reset y estilos base
│   ├── Login.css
│   ├── Header.css
│   ├── NavTabs.css
│   ├── Dashboard.css
│   └── JobCard.css
└── components/
    ├── Login.jsx            # Pantalla de login y registro
    ├── Dashboard.jsx        # Pantalla principal del plomero
    ├── Header.jsx           # Barra superior (nombre, toggle activo)
    ├── NavTabs.jsx          # Tabs de navegación
    └── JobCard.jsx          # Card de solicitud con timer en vivo
```

## Cómo correrlo

```bash
npm create vite@latest plomeria -- --template react
cd plomeria
# Reemplazá el contenido de src/ con estos archivos
npm install
npm run dev
```

## Props principales

### `<Login onLogin={fn} />`
- `onLogin(userData)` — se llama al hacer login, recibe `{ name, location, email }`

### `<Dashboard user={obj} onLogout={fn} />`
- `user` — objeto con `name`, `location`, `email`
- `onLogout` — callback para volver al login

### `<JobCard job={obj} onAccept={fn} onReject={fn} />`
- `job.id` — string único
- `job.category` — "Urgencias" | "Destapes" | etc.
- `job.urgent` — boolean
- `job.timerSeconds` — segundos restantes al montar
- `job.timerTotal` — segundos totales (para la barra de progreso)
- `job.description` — texto del cliente
- `job.turno` — string de turno sugerido (opcional)
